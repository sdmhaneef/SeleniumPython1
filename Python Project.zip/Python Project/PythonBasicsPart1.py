# print("Hellow World")

# #variable are case sensitive
# x=4
# print(type(x)) # gives type of the variable
# x=str(x) #converting integer to string
# print(type(x))
# y="Automation"
# print("Hellow "+x)

# #Syntax
# if(10>5):
#     print("10 is bigger")
# if 10>5:
#     print "10 is bigger"

# #Identation Error(print should have space)
# if 10>5:
# print "10 is bigger"

# #Funciton
# def sum(a,b):
#     print(a+b)
# sum(2,3)

# #casting
# x = int(2)    #2
# y = int(2.5)   #2
# z = float(1)    #1.0
# p = str(10)     #"10"
# print(x)
# print(y)
# print(z)
# print(p)


# #String Operations
# x = "Hellow World"
# print(x)
# print(x[1])
# print(x[6:9])
# print(len(x))
# print(x.lower())
# print(x.upper())
# x = "   Hellow World"
# print(x)
# print(x.strip()) #Remove spaces
# x = "Hellow World"
# print(x.replace("e","a"))
# print(x.split(" "))


#Input Function
print("Enter your Name :")
x1 = raw_input()
print x1
# print("Name ", x)

