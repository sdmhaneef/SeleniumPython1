# #if else and elif
# x=input("Enter a number :")
# if x>0:
#     print("positive number")
# elif x<0:
#     print("negative number")
# else:
#     print("its zero")

#For Loop
num = [1,2,3,4,5]
# for val in num:
#     print(val)
sum=0
for val in num:
    sum=sum+val
print("Total is", sum)