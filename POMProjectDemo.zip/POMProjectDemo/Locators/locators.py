class Locators():

    #Login Page Objets
    username_textbox_id = "txtUsername"
    password_textbox_id = "txtPassword"
    login_button_id = "btnLogin"

    #Home Page Objects
    welcome_link_id = "welcome"
    logout_link_linkText = "Logout"